#ifndef TEMP_H
#define TEMP_H
#include <Arduino.h>
#include <TVout.h>

void temp(TVout TV);

#endif